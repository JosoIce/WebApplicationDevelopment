<header>
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
    <a class="navbar-brand" href="index.php">My Friend System Home</a>
    <ul class="navbar-nav">
        <li class="nav-item active">
            <a class="nav-link" href="signup.php">Sign Up</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="login.php">Log In</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="friendlist.php">Friend List</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="friendadd.php">Friend Add</a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="logout.php">Log Out</a>
        </li>
        <li class="nav-item active">
             <a class="nav-link" href="about.php">About</a>
        </li>
    </ul>
</nav>
</header>