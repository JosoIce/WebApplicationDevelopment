<?php
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s101094376";
    $pswd = "030398";
    $dbnm = "s101094376_db"
?>